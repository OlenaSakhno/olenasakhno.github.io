<aside class="col-md-4">
  <div class="p-3 mb-3 side-color bg-warning rounded">
    <h4><b>Интересные факты</b></h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates iste quas possimus consequuntur, laborum, mollitia nemo, alias tempora quasi sunt aperiam animi at. Architecto totam, ullam repudiandae voluptatum, sit sed.</p>
  </div>
  <div class="p-3 mb-3">
    <img class="img-thumbnail" src="/img/blue-sky-with-clouds-5.jpg">
  </div>
</aside>
