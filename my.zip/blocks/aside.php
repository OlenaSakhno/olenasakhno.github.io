<aside class="col-md-4">
<!--Search-->
<script async src="https://cse.google.com/cse.js?cx=005352034175337425264:v1hf5selwpa"></script>
<div class="gcse-search"></div>


<script async src="https://cse.google.com/cse.js?cx=005352034175337425264:v1hf5selwpa"></script>
<div class="gcse-searchbox"></div>
<br>
  <div class="p-3 mb-3 side-color bg-color rounded">
    <h4><b>Interesting Facts</b></h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates iste quas possimus consequuntur, laborum, mollitia nemo, alias tempora quasi sunt aperiam animi at. Architecto totam, ullam repudiandae voluptatum, sit sed.</p>
  </div>
  <br>
  <div class="p-3 mb-3">
    <img class="img-thumbnail" src="/img/blue-sky-with-clouds-5.jpg">
  </div>

</aside>
