<footer class="footer">
<!--  <div class="container">
    <span class="text-muted">Все права защищены</span>
  </div>-->

  <hr>
<div class="container">
  <a class="foot-link " href="https://github.com/OlenaSakhno">Me on GitHub</a> <span>         &copy; Olena Sakhno</span>
  </div>
</footer>
