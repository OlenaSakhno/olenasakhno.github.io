<footer class="footer">
  <div class="container">
    <span class="text-muted">Все права защищены</span>
  </div>
</footer>
