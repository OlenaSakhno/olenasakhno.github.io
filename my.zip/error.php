<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Ошибка 404</title>
  <link rel="stylesheet" href="/css/bootstrap.min.css">
  <link rel="icon" href="/img/favicon.ico">
  <link rel="stylesheet" href="/css/main.css">
</head>
<body>
  <?php require 'blocks/header.php'; ?>
  Ошибка 404, перейдите <a href="/">на главную</a>
  <?php require 'blocks/footer.php'; ?>
</body>
</html>
