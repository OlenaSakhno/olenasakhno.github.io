<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'OSakhno/Home';
    require 'blocks/head.php';
  ?>
</head>
<body class="body_color">
  <figure>
  <div class="fixed-wrap" id="fixed">
  <?php require 'blocks/header.php'; ?>

<main class="container mt-5">
  <div class="row">
    <div class="col-md-8 mb-3 mt-5 ">


      <h1 >Welcome</h1>
      <p id="Wel">This is my first web site which was created for my learning. I used my knowledge of HTML, CSS, Bootstrap, JavaScript, PHP, MySQL, Ajax and JQuery.</p>


      <hr><hr>
  <!--    <h2 class="nav justify-content-center text-info" >Slider</h2>-->

      <div class="carousel slide carousel-fade" data-ride="carousel" id="slider">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="img/slide-1.jpg" class="d-block w-100" >
            <div class="carousel-caption d-none d-md-block"> <!--Caption-->

              <span>Image by <a href="https://pixabay.com/users/danfador-55851/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=190055">Dan Fador</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=190055">Pixabay</a></span><!--Caption-->

            </div>
          </div>
          <div class="carousel-item">
            <img src="img/slide-2.jpg" class="d-block w-100" >
            <div class="carousel-caption d-none d-md-block"> <!--Caption-->
              <span>Image by <a href="https://pixabay.com/users/JillWellington-334088/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=591576">Jill Wellington</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=591576">Pixabay</a></span>

            </div>
          </div>
          <div class="carousel-item">
            <img src="img/slide-3.jpg" class="d-block w-100" >
            <div class="carousel-caption d-none d-md-block"> <!--Caption-->
              <span>Image by <a href="https://pixabay.com/users/12019-12019/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1751455">David Mark</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1751455">Pixabay</a></span>

            </div>
          </div>
        </div>
      <!--With controls-->
        <a class="carousel-control-prev" href="#slider" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#slider" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
        <ol class="carousel-indicators">
          <li data-target="#slider" data-slide-to="0" class="active"></li>
          <li data-target="#slider" data-slide-to="1"></li>
          <li data-target="#slider" data-slide-to="2"></li>
        </ol>
      </div>
    </div>



<!--

  <main class="container mt-5">
    <div class="row">
      <div class="col-md-8 mb-3 mt-5 ">
        <?php
        require 'mysql_connect.php';
        $sql='SELECT * FROM `articles` ORDER BY `date` DESC';
        $query=$pdo->query($sql);
        while ($row=$query->fetch(PDO::FETCH_OBJ)){
          echo "<h2>$row->title</h2><br>
                <p>$row->intro</p>
                <p><b>Author: </b> <mark> $row->author</mark></p>
                <a href='/news.php?id=$row->id' title='$row->title'> <button class='btn btn-warning mb-50'>Read more</button>
                </a>";
        }
        ?>
      </div>
-->




     <?php require 'blocks/aside.php'; ?>
    </div>
  </main>

  <?php require 'blocks/footer.php'; ?>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>


</div></figure>




Background Image by <a href="https://pixabay.com/users/Pexels-2286921/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1852945">Pexels</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1852945">Pixabay</a>
</body>
</html>
